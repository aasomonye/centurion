<?php
namespace Moorexa;

class Main
{
	protected $license = null;
	protected $hash = null;
	public static $components = [];
}