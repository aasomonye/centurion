# System
This directory serves as the heart of the framework. It contains classes and functions that powers the entire system.