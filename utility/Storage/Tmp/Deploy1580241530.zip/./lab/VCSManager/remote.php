<?php
return [
    'url' => '', // remote url
    'username' => '', // remote username
    'password' => '', // remote password
    'sharedKey' => '' // set a shared key
];