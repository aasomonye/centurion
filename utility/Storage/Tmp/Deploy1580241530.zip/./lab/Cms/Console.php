<?php

/**
 * @package Godoit Extended Assist CLI Helper Commands
 * @author  Moorexa Software Foundation
 */

class Console extends Assist
{
    // commands
    public static $commands = [
        'help' => 'Shows a help screen for Zema.',
        'prod' => 'Runs production commands for assist manager'
    ];

    // command help
    public static $commandHelp = [
        'help' => [
            'info' => 'Shows a help screen for Zema.'
        ],

        'prod' => [
            'info' => 'Runs production commands for assist manager',
            'commands' => [
                'php assist Zema:prod migrate' => 'Run migration for production site'
            ],
            'options' => [
                '-nozema' => 'ignore migration for zema tables',
                '-nodefault|-noglob|-noglobal' => 'ignore migration for default tables'
            ]
        ]
    ];

    // help command definition
    public static function help()
    {
        // display something simple
        self::out('You have reached the help screen for Godoit.');

        // you can also trigger the help method from the parent class
        // => parent::help($arg);

        // you should register this CLI Helper file in kernel/assist.php before use.
    }

    // more static methods.. 
    public static function _new($arg)
    {
        // change controller base path
        parent::$controllerBasePath = HOME . 'lab/Cms/MVC';

        // change table base path
        parent::$tablePath = 'Tables/';

        // ok call parent new method now
        parent::_new($arg);
    }

    // migrate command 
    public static function migrate($arg)
    {
        parent::$assistPath = HOME;
        
        // apply from
        array_push($arg, '-from='.HOME.'lab/Cms/Tables/', '-prefix=Zema_');

        // add save query path
        Moorexa\DB::$queryCachePath = HOME . 'lab/Cms/Database/QueryStatements.php';

        // call migrate method
        parent::migrate($arg);
    }

    // production commands
    public static function prod($arg)
    {
        self::out(PHP_EOL);

        // set your live url
        $liveUrl = 'http://console.fregatelab.com/workspace/centurion/';
        
        // get object
        $ass = new Assist();

        // get action
        $action = $arg[0];

        switch ($action)
        {
            case 'migrate':
                self::sleep('Running migration to production server');

                if ($liveUrl != '')
                {
                    // get tables
                    $tables = array_splice($arg, 1);

                    // start connection
                    self::sleep($ass->ansii('green').'Connecting to'. $ass->ansii('reset').' '.$liveUrl);

                    // get assist token
                    $token = env('bootstrap', 'assist_token');

                    // no zema
                    $noZema = false;

                    // no default
                    $noDefault = false;

                    foreach ($tables as $index => $value)
                    {
                        switch(strtolower($value))
                        {
                            case '-nozema':
                                $noZema = true;
                                unset($tables[$index]);
                            break;

                            case '-nodefault':
                            case '-noglob':
                            case '-noglobal':
                                $noDefault = true;
                                unset($tables[$index]);
                            break;
                        }
                    }

                    // build url
                    $urls = [
                        'zema' => $liveUrl . "?command=".urlencode("Zema:migrate ".implode(',', $tables)),
                        'global' => $liveUrl . "?command=".urlencode("migrate ".implode(',', $tables))
                    ];


                    // set user agent
                    $agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:68.0) Gecko/20100101 Firefox/68.0';

                    // parse url
                    $parseurl = parse_url($liveUrl);

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $liveUrl);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_HEADER, 0);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
                    curl_setopt($ch, CURLOPT_USERAGENT, $agent);   
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: text/html',
                    "assist-cli-token: {$token}",
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language: en-US,en;q=0.5',
                    'Cache-Control: max-age=0',
                    'Connection: keep-alive',
                    'Host: '.$parseurl['host'],
                    'Upgrade-Insecure-Requests: 1',
                    'User-Agent: '.$agent));   
                    curl_setopt($ch, CURLOPT_TIMEOUT, 86400);

                    // run query
                    foreach ($urls as $scope => $url)
                    {
                        $continue = false;

                        switch ($scope)
                        {
                            case 'zema':
                                if ($noZema === false)
                                {
                                    $continue = true;
                                    curl_setopt($ch, CURLOPT_URL, $url);
                                }
                            break;

                            case 'global':
                                if ($noDefault === false)
                                {
                                    $continue = true;
                                    curl_setopt($ch, CURLOPT_URL, $url);
                                }
                            break;
                        }

                        if ($continue)
                        {
                            self::sleep($ass->ansii('green').'Staging Execution for '. $ass->ansii('reset').' '.$url);
                            // execute query
                            $msg = curl_exec($ch);
                            self::sleep($ass->ansii('green').'Running Migration for '.$scope.'..'. $ass->ansii('reset').' Receiving response from server...');
                            self::sleep('=== Response ===');
                            if (curl_errno($ch))
                            {
                                $msg = curl_error($ch);
                            }
                            self::sleep($msg);
                            self::out(PHP_EOL);
                        }
                    }

                    self::sleep('Closing Connection.');
                    // close connection
                    curl_close($ch);
                    
                }
                else
                {
                    self::out(PHP_EOL.$ass->ansii('red').'Could not proceed. LiveURL not configured in '. __FILE__);
                }
            break;   
        }

        self::out(PHP_EOL);
    }
}