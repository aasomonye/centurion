var codebox = document.querySelector('#codebox');
if (codebox !== null)
{
    codebox.nextElementSibling.value = codebox.innerHTML;
}