<?php

return array (
  'centurion-app' => 
  array (
    'Zema_images' => 
    array (
      'a286f9b576f80783bc57ae12c5289bbc11745379a5db06ea529c5981c25216881dfe436f' => 
      array (
        'query' => 'UPDATE Zema_images SET image_path = :image_path , image_name = :image_name  WHERE imageid=:imageid ',
        'bind' => 
        array (
          'image_path' => './lab/Cms/MVC/App/Uploads/5dadb98f9286ae7902395c4d73cee36a3804.jpg',
          'image_name' => 'slide1-bg',
          'imageid' => '1',
        ),
      ),
      'a286f9b576f80783bc57ae12c5289bbc11693228f380f73a1beca47e87efdc50aa20228e' => 
      array (
        'query' => 'UPDATE Zema_images SET image_path = :image_path , image_name = :image_name  WHERE imageid=:imageid ',
        'bind' => 
        array (
          'image_path' => './lab/Cms/MVC/App/Uploads/d585c3448b63483976403179af9391448972.jpg',
          'image_name' => 'slide2-bg',
          'imageid' => '2',
        ),
      ),
      'a286f9b576f80783bc57ae12c5289bbcb541a7ebd304de3e12cfc9e31a1abe3d6155459d' => 
      array (
        'query' => 'UPDATE Zema_images SET image_path = :image_path , image_name = :image_name  WHERE imageid=:imageid ',
        'bind' => 
        array (
          'image_path' => './lab/Cms/MVC/App/Uploads/3f300023b4831cc89c4ffad089585ad2OE9UOO0.jpg',
          'image_name' => 'slide3-bg',
          'imageid' => '3',
        ),
      ),
      '9aea5e176467cc4c7dee6f23ad82e932fbcdfa5fccf56273884fb1803764d4e1bed4ab02' => 
      array (
        'query' => 'INSERT INTO Zema_images (image_path,image_name,siteid) VALUES (:image_path0,:image_name0,:siteid0)',
        'bind' => 
        array (
          'image_path0' => './lab/Cms/MVC/App/Uploads/24011eccd02d490bafe27eea2b7a699f5051.jpg',
          'image_name0' => 'slide4-bg',
          'siteid0' => 'Centurion',
        ),
      ),
      '9aea5e176467cc4c7dee6f23ad82e9320e820f4cce6e6fa070a2777ebc352bed98672ed6' => 
      array (
        'query' => 'INSERT INTO Zema_images (image_path,image_name,siteid) VALUES (:image_path0,:image_name0,:siteid0)',
        'bind' => 
        array (
          'image_path0' => './lab/Cms/MVC/App/Uploads/a0652874a7294982ef670617bf8c7f401587.jpg',
          'image_name0' => 'slide5-bg',
          'siteid0' => 'Centurion',
        ),
      ),
      '9aea5e176467cc4c7dee6f23ad82e93226d91eb3af46255e80de52a9f51c9cdf4317cf30' => 
      array (
        'query' => 'INSERT INTO Zema_images (image_path,image_name,siteid) VALUES (:image_path0,:image_name0,:siteid0)',
        'bind' => 
        array (
          'image_path0' => './lab/Cms/MVC/App/Uploads/1cb43d9b901e6c83061fb3ca1f0319682449320.jpg',
          'image_name0' => 'slide6-bg',
          'siteid0' => 'Centurion',
        ),
      ),
    ),
  ),
);

?>